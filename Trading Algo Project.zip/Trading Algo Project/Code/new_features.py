from tkinter import*
from tkinter import ttk
#to insert img for bg we will use pillow library
from PIL import Image,ImageTk
#importing msg box for errors
from tkinter import messagebox

import mysql.connector  # pip3 install pymysql

class Login_Window:
    #constructor for login class
    def __init__(self, root):
        self.root = root
        self.root.title("Login Page")  # For Title of the page
        self.root.geometry("1350x700+0+0")    # Resolution of the page , top, bottom
        self.root.config(bg="white")
        
        # ===BackGround Image===
        self.bg = ImageTk.PhotoImage(file="images/back4.jpg")
        #displaying bg image by using label
        bg = Label(self.root, image=self.bg)
        #placing the image using relative width and height so that whenever window chnges it can place itself properly
        bg.place(x=0, y=0, relwidth=1, relheight=1)

        # ===Login Frame===
        frame = Frame(self.root,bg="white")
        frame.place(x=200,y=170,width=340,height=450)

        #inserting image on frame
        img1=Image.open("images/main.jpg")
        img1=img1.resize((105,90),Image.ANTIALIAS)
        #resizing(width,height)
        #antialias converts high level img to low level
        #img1 saved to photoimage1
        self.photoimage1=ImageTk.PhotoImage(img1)
        #self.photoimage1=ImageTk.PhotoImage(file = "images/main.jpg")
        #images can be inserted via frames
        lblimg1=Label(image=self.photoimage1,bg="white",borderwidth=0)
        lblimg1.place(x=620,y=170,width=105,height=90)
        #we need label inside frame
        get_str=Label(frame,text="Features Coming Soon",font=("times new roman",20,"bold"),fg="black",bg="white")
        get_str.place(x=44,y=60)

        #Content of new features
        email=lbl=Label(frame,text="Range Trading",font=("times new roman",12,"bold"),fg="black",bg="white")
        email.place(x=70,y=140)

        email=lbl=Label(frame,text="Trend Trading",font=("times new roman",12,"bold"),fg="black",bg="white")
        email.place(x=70,y=165)
       
        email=lbl=Label(frame,text="Breakout trading",font=("times new roman",12,"bold"),fg="black",bg="white")
        email.place(x=70,y=190)

        email=lbl=Label(frame,text="Reversal Trading",font=("times new roman",12,"bold"),fg="black",bg="white")
        email.place(x=70,y=215)

        email=lbl=Label(frame,text="Gap Trading",font=("times new roman",12,"bold"),fg="black",bg="white")
        email.place(x=70,y=240)

        email=lbl=Label(frame,text="Momentum Trading",font=("times new roman",12,"bold"),fg="black",bg="white")
        email.place(x=70,y=265)

        email=lbl=Label(frame,text="Arbitrage Trading",font=("times new roman",12,"bold"),fg="black",bg="white")
        email.place(x=70,y=290)

        email=lbl=Label(frame,text="Pairs trading Trading",font=("times new roman",12,"bold"),fg="black",bg="white")
        email.place(x=70,y=315)

        email=lbl=Label(frame,text="Short Selling",font=("times new roman",12,"bold"),fg="black",bg="white")
        email.place(x=70,y=340)



        
        #Signup button
        signupbtn=Button(frame,text="Go to Homepage", command=self.register_window,font=("times new roman",10,"bold"),borderwidth=0,fg="black",bg="white",activeforeground="blue",activebackground="white")
        signupbtn.place(x=60,y=390,width=220)

    #function for validation which will be called inside login button
    #by using command=self.funcname
    def register_window(self):
        self.root.destroy()
        import homepage

    def clear_data(self):
        self.txtemail.delete(0,END)
        self.txtpass.delete(0, END)

    def login(self) : 
        email = self.txtemail.get()
        password = self.txtpass.get()
        if email=="" or password=="":
            messagebox.showerror("Error:","all fields required")

        else:
            con = mysql.connector.connect(host="localhost", user="root",passwd="password",database='vipuldb')
            cur = con.cursor()
            
            cur.execute("select * from record where email= '"+ email+"' and password= '"+password+"'")
            row = cur.fetchone()
            if row == None:
                messagebox.showerror("Error !","Invalid User Email or Password", parent=self.root)
            else:
                
                messagebox.showinfo("Login Successful","Welcome", parent=self.root)
            self.clear_data()
            con.commit()
            con.close()

        #destroy current window
        self.root.destroy()
        #move to User HomePage
        import homepage
        
root = Tk()
obj = Login_Window(root)
root.mainloop()