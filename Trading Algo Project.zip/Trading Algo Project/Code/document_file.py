import os

log_path = os.getcwd()
client_id = 
secret_key =
redirect_url = 'https://myapi.fyers.in/'
username = 
password = 
pin1 = 
pin2 = 
pin3 = 
pin4 = 
response_type = 'code'
grant_type = 'authorization_code'