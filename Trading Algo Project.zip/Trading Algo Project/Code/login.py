from tkinter import*
from tkinter import ttk
#to insert img for bg we will use pillow library
from PIL import Image,ImageTk
#importing msg box for errors
from tkinter import messagebox

import mysql.connector  # pip3 install pymysql

class Login_Window:
    #constructor for login class
    def __init__(self, root):
        self.root = root
        self.root.title("Login Page")  # For Title of the page
        self.root.geometry("1350x700+0+0")    # Resolution of the page , top, bottom
        self.root.config(bg="white")
        
        # ===BackGround Image===
        self.bg = ImageTk.PhotoImage(file="images/back1.jpg")
        #displaying bg image by using label
        bg = Label(self.root, image=self.bg)
        #placing the image using relative width and height so that whenever window chnges it can place itself properly
        bg.place(x=0, y=0, relwidth=1, relheight=1)

        # ===Login Frame===
        frame = Frame(self.root,bg="white")
        frame.place(x=500,y=170,width=340,height=450)

        #inserting image on frame
        img1=Image.open("images/icon_login.png")
        img1=img1.resize((105,90),Image.ANTIALIAS)
        #resizing(width,height)
        #antialias converts high level img to low level
        #img1 saved to photoimage1
        self.photoimage1=ImageTk.PhotoImage(img1)
        #self.photoimage1=ImageTk.PhotoImage(file = "images/icon_login.png")
        #images can be inserted via frames
        lblimg1=Label(image=self.photoimage1,bg="white",borderwidth=0)
        lblimg1.place(x=620,y=170,width=105,height=90)
        #we need label inside frame
        get_str=Label(frame,text="Log in to Trade",font=("times new roman",20,"bold"),fg="black",bg="white")
        get_str.place(x=85,y=85)

        #label for email 
        email=lbl=Label(frame,text="User Email",font=("times new roman",16,"bold"),fg="black",bg="white")
        email.place(x=70,y=140)
        #entry for email
        self.txtemail=ttk.Entry(frame,font=("times new roman",16,"bold"))
        self.txtemail.place(x=35,y=170,width=270)

        #label for password 
        password =lbl=Label(frame,text="Password",font=("times new roman",16,"bold"),fg="black",bg="white")
        password .place(x=70,y=210)
        #entry for password
        self.txtpass=ttk.Entry(frame,font=("times new roman",16,"bold"),show="*")
        self.txtpass.place(x=35,y=240,width=270)

        #icon images
        #inserting image on frame
        img2=Image.open("images/icon_user.png")
        img2=img2.resize((25,25),Image.ANTIALIAS)
        self.photoimage2=ImageTk.PhotoImage(img2)
        #self.photoimage2=ImageTk.PhotoImage(file="images/icon_user.png")
        lblimg2=Label(image=self.photoimage2,bg="white",borderwidth=0)
        lblimg2.place(x=540,y=313,width=25,height=25)

        img3=Image.open("images/icon_pass.png")
        img3=img3.resize((25,25),Image.ANTIALIAS)
        self.photoimage3=ImageTk.PhotoImage(img3)
        #self.photoimage3=ImageTk.PhotoImage(file="images/icon_pass.png")
        lblimg3=Label(image=self.photoimage3,bg="white",borderwidth=0)
        lblimg3.place(x=540,y=383,width=25,height=25)

        #Login Button 
        #border=bd #border style=relief
        loginbtn=Button(frame,command=self.login,text="Login", font=("times new roman",16,"bold"),bd=3,relief=RIDGE,fg="white",bg="red",activeforeground="white",activebackground="black")
        loginbtn.place(x=110,y=290,width=120,height=35)

        #Signup button
        signupbtn=Button(frame,text="New User? Sign Up", command=self.register_window,font=("times new roman",10,"bold"),borderwidth=0,fg="black",bg="white",activeforeground="blue",activebackground="white")
        signupbtn.place(x=9,y=340,width=160)

        #forgotpass button
        #forgotpassbtn=Button(frame,text="Forgot Password",font=("times new roman",10,"bold"),borderwidth=0,fg="black",bg="white",activeforeground="blue",activebackground="white")
        #forgotpassbtn.place(x=3,y=370,width=160)


    #function for validation which will be called inside login button
    #by using command=self.funcname
    def register_window(self):
        self.root.destroy()
        import register

    def clear_data(self):
        self.txtemail.delete(0,END)
        self.txtpass.delete(0, END)

    def login(self) : 
        email = self.txtemail.get()
        password = self.txtpass.get()
        if email=="" or password=="":
            messagebox.showerror("Error:","all fields required")

        else:
            con = mysql.connector.connect(host="localhost", user="root",passwd="rootpassword@1234",database='vipuldb')
            cur = con.cursor()
            
            cur.execute("select * from record where email= '"+ email+"' and password= '"+password+"'")
            row = cur.fetchone()
            if row == None:
                messagebox.showerror("Error !","Invalid User Email or Password", parent=self.root)
            else:
                
                messagebox.showinfo("Login Successful","Welcome", parent=self.root)
                #destroy current window
                self.root.destroy()
                #move to User HomePage
                import homepage
            self.clear_data()
            con.commit()
            con.close()


        
root = Tk()
obj = Login_Window(root)
root.mainloop()