from tkinter import*
from tkinter import ttk
#to insert img for bg we will use pillow library
from PIL import Image,ImageTk
#importing msg box for errors
from tkinter import messagebox
import fyers
import mysql.connector  # pip3 install pymysql

class Homepage_Window:
    #constructor for login class
    def __init__(self, root):
        self.root = root
        self.root.title("Login Page")  # For Title of the page
        self.root.geometry("1350x700+0+0")    # Resolution of the page , top, bottom
        self.root.config(bg="white")
        global connection_check 
        connection_check= False
        # ===BackGround Image===
        self.bg = ImageTk.PhotoImage(file="images/back3.jpg")
        #displaying bg image by using label
        bg = Label(self.root, image=self.bg)
        #placing the image using relative width and height so that whenever window chnges it can place itself properly
        bg.place(x=0, y=0, relwidth=1, relheight=1)

        # ===Login Frame===
        frame = Frame(self.root,bg="white")
        frame.place(x=500,y=170,width=440,height=510)

        #inserting image on frame
        img1=Image.open("images/main.jpg")
        img1=img1.resize((125,90),Image.ANTIALIAS)
        #resizing(width,height)
        #antialias converts high level img to low level
        #img1 saved to photoimage1
        self.photoimage1=ImageTk.PhotoImage(img1)
        #self.photoimage1=ImageTk.PhotoImage(file = "images/main.jpg")
        #images can be inserted via frames
        lblimg1=Label(image=self.photoimage1,bg="white",borderwidth=0)
        lblimg1.place(x=668,y=170,width=105,height=90)
        #we need label inside frame
        get_str=Label(frame,text="Trading Algo Stratergies",font=("times new roman",20,"bold"),fg="black",bg="white")
        get_str.place(x=85,y=85)

        #label Moving Average 
        email=lbl=Label(frame,text="Moving Average",font=("times new roman",16,"bold"),fg="black",bg="white")
        email.place(x=40,y=310)
       
        #scalp text 
        password =lbl=Label(frame,text="Scalp",font=("times new roman",16,"bold"),fg="black",bg="white")
        password .place(x=300,y=310)
    
        #Scalp Trade Button 
        #border=bd #border style=relief
        scalptradebtn=Button(frame,text="Trade",font=("times new roman",16,"bold"),bd=3,relief=RIDGE,fg="white",bg="midnightblue",activeforeground="white",activebackground="black")
        scalptradebtn.place(x=265,y=345,width=120,height=35)

        #Logout Button s
        #border=bd #border style=relief
        logoutbtn=Button(text="Logout",command=self.login_window,font=("times new roman",16,"bold"),bd=3,relief=RIDGE,fg="white",bg="crimson",activeforeground="white",activebackground="black")
        logoutbtn.place(x=1220,y=10,width=120,height=35)


        #rdbtn = Radiobutton(frame, text="Red", bg="red",variable = "1", value="R", command=self.on_RadioChange)
        #rdbtn.place(x=1200,y=10,width = 10,height=10)
        #Connect to fyers Button 
        #border=bd #border style=relief
        fyersconnectbtn=Button(text="Connect to Fyers",command=self.connection_window,font=("times new roman",14,"bold"),bd=3,relief=RIDGE,fg="white",bg="dodgerblue",activeforeground="white",activebackground="black")
        fyersconnectbtn.place(x=1050,y=10,width=160,height=35)

        #icon images
        #inserting image on frame
        img2=Image.open("images/moving_average.jpg")
        img2=img2.resize((25,25),Image.ANTIALIAS)
        self.photoimage2=ImageTk.PhotoImage(img2)
        #self.photoimage2=ImageTk.PhotoImage(file="images/moving_average.jpg")
        lblimg2=Label(image=self.photoimage2,bg="white",borderwidth=0)
        lblimg2.place(x=510,y=483,width=25,height=25)

        img3=Image.open("images/scalp.jpg")
        img3=img3.resize((25,25),Image.ANTIALIAS)
        self.photoimage3=ImageTk.PhotoImage(img3)
        #self.photoimage3=ImageTk.PhotoImage(file="images/scalp.jpg")
        lblimg3=Label(image=self.photoimage3,bg="white",borderwidth=0)
        lblimg3.place(x=775,y=485,width=25,height=25)

        self.cmb_stock_option = ttk.Combobox(frame, font=("times new roman", 13), state='readonly', justify=CENTER)
        self.cmb_stock_option['values']=("NIFTY 50","HDFCBANK-EQ","SBIN-EQ","INFY-EQ")
        self.cmb_stock_option.place(x=101, y=160, width=250)
        self.cmb_stock_option.current(0)

        #Moving Average trade button
        #border=bd #border style=relief
        movingaveragebtn=Button(frame,command=self.moving_average_trade,text="Trade",font=("times new roman",16,"bold"),bd=3,relief=RIDGE,fg="white",bg="midnightblue",activeforeground="white",activebackground="black")
        movingaveragebtn.place(x=58,y=346,width=120,height=35)

        #Explore more options button
        Explorebtn=Button(frame,text="Explore More Trading Stratergies", command=self.homepage_window,font=("times new roman",10,"bold"),borderwidth=0,fg="black",bg="white",activeforeground="blue",activebackground="white")
        Explorebtn.place(x=110,y=460,width=220)

        #Coming soon button
        comingsoonbtn=Button(frame,text="(Features Coming Soon)",font=("times new roman",10,"bold"),borderwidth=0,fg="black",bg="white",activeforeground="blue",activebackground="white")
        comingsoonbtn.place(x=110,y=480,width=220)


    #function for validation which will be called inside login button
    #by using command=self.funcname
    def homepage_window(self):
        self.root.destroy()
        import new_features
    def login_window(self):
        self.root.destroy()
        import login
    def clear_data(self):
        self.txtemail.delete(0,END)
        self.txtpass.delete(0, END)
    def connection_window(self):
        message=fyers.fyers_connect()
        if message == "Connected!":
            connection_check = True
        
        messagebox.showinfo("Connection with Fyers",message, parent=self.root)
    def moving_average_trade(self):
        message = fyers.moving_average(self.cmb_stock_option.get())
        messagebox.showinfo("Moving Average",message, parent=self.root)
root = Tk()
obj = Homepage_Window(root)
root.mainloop()