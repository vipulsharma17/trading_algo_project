# pip install fyers-apiv2
# pip install selenium
# pip install webdriver-manager
# pip install pandas
# pip install TA_Lib-0.4.24-cp310-cp310-win_amd64.whl
# https://www.lfd.uci.edu/~gohlke/pythonlibs/#ta-lib

from fyers_api.Websocket import ws
from fyers_api import fyersModel
from fyers_api import accessToken
import datetime
import time
import document_file
from selenium import webdriver
from webdriver_manager.firefox import GeckoDriverManager
import talib as ta
import pandas as pd

log_path = document_file.log_path
client_id = document_file.client_id
secret_key = document_file.secret_key
redirect_url = document_file.redirect_url
response_type = document_file.response_type
grant_type = document_file.grant_type
username = document_file.username
password = document_file.password
pin1 = document_file.pin1
pin2 = document_file.pin2
pin3 = document_file.pin3
pin4 = document_file.pin4

def generate_access_token(auth_code, appId, secret_key):
	appSession = accessToken.SessionModel(client_id=appId, secret_key=secret_key,grant_type="authorization_code")
	appSession.set_token(auth_code)
	response = appSession.generate_token()["access_token"]
	return response

def generate_auth_code():
	url = f"https://api.fyers.in/api/v2/generate-authcode?client_id={client_id}&redirect_uri={redirect_url}&response_type=code&state=state&scope=&nonce="
	driver = webdriver.Firefox(executable_path=GeckoDriverManager().install())
	# driver = webdriver.Firefox(executable_path=r"C:\Users\tradi\.wdm\drivers\geckodriver\win64\v0.30.0\geckodriver.exe")
	driver.get(url)
	time.sleep(4)
	driver.execute_script(f"document.querySelector('[id=fy_client_id]').value = '{username}'")
	driver.execute_script("document.querySelector('[id=clientIdSubmit]').click()")
	time.sleep(20)
	#driver.execute_script(f"document.querySelector('[id=fy_client_pwd]').value = '{password}'")
	#driver.execute_script("document.querySelector('[id=loginSubmit]').click()")
	#time.sleep(8)
	#driver.find_element_by_id("verify-pin-page").find_element_by_id("first").send_keys(pin1)
	#driver.find_element_by_id("verify-pin-page").find_element_by_id("second").send_keys(pin2)
	#driver.find_element_by_id("verify-pin-page").find_element_by_id("third").send_keys(pin3)
	#driver.find_element_by_id("verify-pin-page").find_element_by_id("fourth").send_keys(pin4)
	#driver.execute_script("document.querySelector('[id=verifyPinSubmit]').click()")
	#time.sleep(4)
	newurl = driver.current_url
	auth_code = newurl[newurl.index('auth_code=')+10:newurl.index('&state')]
	driver.quit()
	return auth_code

def fyers_connect():
    global fyers
    auth_code = generate_auth_code()
    access_token = generate_access_token(auth_code, client_id, secret_key)
    fyers = fyersModel.FyersModel(token=access_token, log_path=log_path, client_id=client_id)
    fyers.token = access_token
    return fyers